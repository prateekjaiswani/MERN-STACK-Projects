import java.util.*;

public class Functions {
    // public static void printMyName(String name){
    //     System.out.println(name);
    //     return ;
    // }

    // public static int Sum(int a, int b){
    //         int sum = a + b;
    //         return sum;
    //     }

    //  public static int Mult(int a, int b){
    //         int prod = a * b;
    //         return prod;
    //     }

    // public static int Factorial(int n){

    //             if(n<0){
    //                 return n;
    //             }

    //             for(int i=n-1;i>=1;i--){
    //                 n=n*i;
    //             }
    //             return n;
    //         }

    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();

        // int a = sc.nextInt();
        // int b = sc.nextInt();

        // System.out.println(Mult(a,b)); 
        // System.out.println(Sum(a,b)); 

        // System.out.println(Factorial(n));


        // printMyName(n);
    }
}