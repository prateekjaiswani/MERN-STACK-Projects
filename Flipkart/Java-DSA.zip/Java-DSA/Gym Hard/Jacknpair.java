import java.util.*;
// import java.io.*;

public class Jacknpair{
	public static int solve(int n){
		//Write your code here
		int ans=0;
		for(int i=n+1;i<=n*n+n;i++){
			if((n*n) % (i-n)==0){
				ans+=1;
			}
		}
		return ans;
	}

	public static void main(String[] args){
		Scanner scr=new Scanner(System.in);
        int n=scr.nextInt();
		int ans=solve(n);
		System.out.println(ans);
	}
}