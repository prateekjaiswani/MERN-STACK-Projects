import java.util.Scanner;
public class Mariotiles {


    public static int countWaysToTile(int w) {
        // Write your code here
		if(w==2){
			return 2;
		}
		if(w==1){
			return 1;
		}

		int vert= countWaysToTile(w-1);
		int horiz= countWaysToTile(w-2);

		return vert + horiz;
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int w = scanner.nextInt();
        Solution solution = new Solution();
        System.out.println(solution.countWaysToTile(w));
    }
}

