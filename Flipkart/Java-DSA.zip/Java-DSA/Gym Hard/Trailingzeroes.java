public static int TRAILINGZEROES(int n){
    // write code here
    int count=0;
    int i=5;
    while(i<=n){
        count+=n/i;
        i*=5;
    }
    return count;
}

// kitne 5 and kitne 5 ke multiples available 25 kitne 125 kitne 
// total utne zeroes