import java.io.IOException;
import java.util.*;

public class Test {
    public static void main(String[] args) throws IOException {
       Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		int arr[]=new int[n];
		for(int i=0;i<n;i++){
			int a=sc.nextInt();
			arr[i]=a;
		}
		// int i=0;
		// while(i<arr.length){
		// System.out.print(arr[i]);
		// 	i++;
		// }

		int i=0;
		int j=0;
		while(arr[j+1]>arr[j]){
			j++;
		}
		j++;
		System.out.println(j);
		int min=j;
		while(i<j && min<arr.length){
			if(arr[i]<=arr[min]){
				System.out.print( arr[i] + " ");
				i++;
			}else{
				System.out.print( arr[min] + " ");
				min++;
			}
		}
		while(i<j){
			System.out.print( arr[i] + " ");
				i++;
		}
		while(min<arr.length){
			System.out.print( arr[min] + " ");
				min++;
		}
		
    }
}
