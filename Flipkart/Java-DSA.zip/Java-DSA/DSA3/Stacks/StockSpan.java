package DSA3.Stacks;

import java.io.*;
import java.util.*;
public class StockSpan {


    public static void main(String args[]) {
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();
        int a[] = new int[n];
        for(int i = 0; i < n; i++){
            a[i] = input.nextInt();
        }
        Solution s  = new Solution();
        int ans[] = s.stockSpans(a);
        for(int i = 0; i < n; i++){
            System.out.print(ans[i] + " ");
        }
    }
}

class Solution {
    static int[] stockSpans(int[] a) {
        Stack<Integer> st= new Stack<>();
        int newarr[]= new int[a.length];
		for(int i=0;i<a.length;i++){
			
			System.out.println(st.size());
			while(st.size()>0 && a[st.peek()]<=a[i]){
				st.pop();
			}
			if(st.size()==0) {
				newarr[i]=i+1;
			}
			else{
				newarr[i]=i-st.peek();
			}
			
			st.push(i);
		}
		return newarr;
		
    }

}
