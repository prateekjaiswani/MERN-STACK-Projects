package DSA3.Stacks;

import java.io.*;
import java.util.*;

public class infixAns {

  public static void main(String[] args) throws Exception {
    BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
    String exp = br.readLine();
    Solution ob =new Solution();
    ob.evaluate(exp);
  }
}

class Solution{
    public void evaluate(String exp){
        //Write code here
		solve(exp);
    }

	public int eval(int n1, int n2, char o){
		if(o=='+') return n1+n2;
		if(o=='-') return n1-n2;
		if(o=='*') return n1*n2;
		if(o=='/') return n1/n2;

		return 0;
	}

	public int getpriority(char o){
		if(o=='+' || o=='-') return 1;
		else return 2;
	}
	public void solve(String exp){
		Stack<Integer> num= new Stack<>();
		Stack<Character> op= new Stack<>();


		for(int i=0;i<exp.length();i++){
			char ch=exp.charAt(i);
			if(ch=='('){
				op.push(ch);
			}else if(Character.isDigit(ch)){
				int n=Integer.parseInt(String.valueOf(ch));
				num.push(n);
			}else if(ch==')'){
				while(op.size()>0 && op.peek()!='('){
					int n2=num.pop();
					int n1=num.pop();
					char o=op.pop();

					int ans= eval(n1,n2,o);
					num.push(ans);
					
					
				}
				op.pop();
			}else{
				int currprior= getpriority(exp.charAt(i));
				while(op.size()>0 && op.peek()!='(' && getpriority(op.peek())>=currprior){
					int n2=num.pop();
					int n1=num.pop();
					char o=op.pop();

					int ans= eval(n1,n2,o);
					num.push(ans);
					
				}
				op.push(ch);
			}
		}

		while(op.size()>0){
			int n2=num.pop();
					int n1=num.pop();
					char o=op.pop();

					int ans= eval(n1,n2,o);
					num.push(ans);
		}

		System.out.println(num.pop());
		
	}

}
