import java.io.*;
import java.util.*;

class Solution{
	public long minSubarraySum(int n, int a[]){
		// write code here
		Stack<Integer> st= new Stack<>();

		// Number of subarrays in which element is minimum = number of starts * number of ends ;
		
		int nextsmallright[]= new int[n];
		int nextsmallleft[]= new int[n];

		//nser
		for(int i=0;i<n;i++){

			while( st.size()>0 && a[i]<=a[st.peek()] ){ // <=to prevent overlapping solutions 
				nextsmallright[st.peek()]=i;    /// 12345 /// 
				st.pop();
			}
			st.push(i);
			
		}

		while(st.size()>0) {
			nextsmallright[st.peek()]=n;
			st.pop();
		}
			/// nsel
		for(int i=n-1;i>=0;i--){

			while( st.size()>0 && a[i]<a[st.peek()]){
				nextsmallleft[st.peek()]=i;
				st.pop();
			}
			st.push(i);
		}

		while(st.size()>0) {
				nextsmallleft[st.peek()]=-1;
			st.pop();
		}

		// number of subarrays
		long m=1000000007;
		long totalsum=0;
		for(int i=0;i<n;i++){
			long startingpoints=i-nextsmallleft[i];
			long endingpoints=nextsmallright[i]-i;

			long numofsubs= (startingpoints%m * endingpoints%m)%m;
			long sum=(a[i]%m*numofsubs%m)%m;
			totalsum=(totalsum%m+sum%m)%m;
		}

		return totalsum;

	}
		
}

public class SumOfSubarrayMinimums {
    public static void main(String args[]) {
        Scanner input = new Scanner(System.in);
        int n = input.nextInt();
        int a[] = new int[n];
        for(int i = 0; i < n; i++){
            a[i] = input.nextInt();
        }
		Solution Obj = new Solution();
        System.out.println(Obj.minSubarraySum(n,a));
    }
}