package DSA3.Stacks;

import java.util.*;
import java.lang.*;
import java.io.*;
public class LargestHistogram {


	public static void main (String[] args) throws IOException {
	BufferedReader br = new BufferedReader(new InputStreamReader(System.in));	
        long n = Long.parseLong(br.readLine().trim());
        String inputLine[] = br.readLine().trim().split(" ");
        long[] arr = new long[(int)n];
        for(int i=0; i<n; i++)arr[i]=Long.parseLong(inputLine[i]);
        System.out.println(new Solution().maximumArea(arr, n));
	}
}

class Solution
{
      public static long maximumArea(long hist[], long n){
	//Your code here   
		  Stack<Integer> st = new Stack<>();
		  long nser[]=new long[(int)n];
		  long nsel[]=new long[(int)n];

		  for(int i=(int)n-1;i>=0;i--){
			  long temp = hist[i];
			  while(st.size()>0 && hist[st.peek()]>=hist[i]){
				  st.pop();
			  }

			  if(st.size()==0) nser[i]=n;
			  else nser[i]=st.peek();

			  st.push(i);
		  }
		  st= new Stack<>();
		  for(int i=0;i<(int)n;i++){
			  long temp = hist[i];
			  while(st.size()>0 && hist[st.peek()]>=hist[i]){
				  st.pop();
			  }

			  if(st.size()==0) nsel[i]=-1;
			  else nsel[i]=st.peek();

			  st.push(i);
		  }
		long size=0;
		  for(int i=0;i<n;i++){
			  if((nser[i]-nsel[i]-1)*hist[i]>size){
				  size=(nser[i]-nsel[i]-1)*hist[i];
			  }
		  }
		  return size;
    }

}
