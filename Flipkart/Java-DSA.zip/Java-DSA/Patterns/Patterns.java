package Patterns;

public class Patterns {

    public static void main(String[] args) {

        // rectangle

        // for (int i = 1; i <= 4; i++) {
        //     for (int j = 1; j <= 5; j++) {
        //         System.out.print("*");
        //     }
        //     System.out.println();
        // }

        // hollow rectangle

        // for(int i=1;i<=4;i++){
        //     for(int j=1;j<=5;j++){
        //         //(i == 1 || j == 1 || i == 4 ||j==5)
        //         if(i>1 && j>1 && i<4 && j<5) {
        //             System.out.print(" ");
        //         }else{
        //             System.out.print("*");
        //         }
        //     }
        //     System.out.println();
        // }

        // half Pyramid

        // for(int i=1;i<=4;i++){
        //     for(int j=1;j<=i;j++){
        //         System.out.print("*");
        //     }
        //     System.out.println();
        // }

        // inverted half  pyramid 

        
        // for(int i=4;i>=1;i--){
        //     for(int j=1;j<=i;j++){
        //         System.out.print("*");
        //     }
        //     System.out.println();
        // }

        //left side of pyramid

       
        // for(int i=1;i<=4;i++){
        //     for(int j=0;j<4-i;j++){
        //         System.out.print(" ");
        //     }
        //     for(int j=1;j<=i;j++){
        //         System.out.print("*");
        //     }
        //     System.out.println();  
        // }

        //number pyramid

        // for(int i=1;i<=5;i++){
        //     for(int j=1;j<=i;j++){
        //         System.out.print(j);
        //     }
        //     System.out.println();
        // }

        // invert half number pyramid

        // for(int i=4;i>=1;i--){
        //     for(int j=1;j<=i;j++){
        //         System.out.print(j);
        //     }
        //     System.out.println();
        // }

        // floyd's triangle 12345678910

        // int n = 5; // row
        // int count = 1;
        // for (int i = 1 ; i<=n ; i++){
        //     for (int j = 1; j <= i ;j++){
        //         System.out.print(count);
        //         count++;
        //     }
        //     System.out.println();
        // }

        //0-1 triangle

        // for(int i = 1; i<=5 ; i++){
        //     for(int j=1; j<=i;j++){
        //         if((i+j)%2==0){
        //             System.out.print("1");
        //         }else{
        //             System.out.print("0");
        //         }
        //     }
        //     System.out.println();
        // }


        //###ADVANCE PATTERNS


        //Butterfly patterns

        // int n = 4;
        

        // for(int i=1;i<=n;i++){
        //     int space = 2*(n-i);
        //     for(int j = 1; j <=i ; j++){
        //         System.out.print("*");
        //     }

        //     for(int j =1;j<=space;j++){
        //         System.out.print(" ");
        //     }

        //     for(int j = 1; j <=i ; j++){
        //         System.out.print("*");
        //     }
        //     System.out.println();
        // }
        // for(int i=n;i>=1;i--){
        //     int space= 2*(n-i);
        //     for(int j = 1; j <=i ; j++){
        //         System.out.print("*");
        //     }

        //     for(int j=1;j<=space;j++){
        //         System.out.print(" ");
        //     }

        //     for(int j = 1; j <=i ; j++){
        //         System.out.print("*");
        //     }
        //     System.out.println();
        // }


        //Solid Rhombus

        // for(int i=1;i<=5;i++){
        //     for(int j=1;j<=5-i;j++){
        //         System.out.print(" ");
        //     }
        //     for(int j=1;j<=5;j++){
        //         System.out.print("*");
        //     }
        //     System.out.println();
        // }

        //number Pyramid

        // for(int i =1 ; i<=5 ; i++ ){
        //     for(int j=1;j<=5-i;j++){
        //         System.out.print(" ");
        //     }
        //     for(int j=1;j<=i;j++){
        //         System.out.print(i+" ");
        //     }
        //     System.out.println();
        // }

        // Palindromic Pattern

        // for (int i=1;i<=5;i++){
        //     for(int j=1;j<=5-i;j++){
        //         System.out.print(" ");
        //     }
        //     for(int j=i;j>=1;j--){
        //         System.out.print(j);
        //     }
        //     for(int j=2;j<=i;j++){
        //         System.out.print(j);
        //     }
        //     System.out.println();
        // }

        
        //Diamond

        // for(int i=1;i<=4;i++){
        //     for(int j=1;j<=4-i;j++){
        //         System.out.print(" ");
        //     }
        //     for(int j=1;j<=2*i-1;j++){
        //         System.out.print("*");
        //     }
        //     System.out.println();
        // }

        // for(int i=4;i>=1;i--){
        //     for(int j=1;j<=4-i;j++){
        //         System.out.print(" ");
        //     }
        //     for(int j=1;j<=2*i-1;j++){
        //         System.out.print("*");
        //     }
        //     System.out.println();
        // }




    }
}
