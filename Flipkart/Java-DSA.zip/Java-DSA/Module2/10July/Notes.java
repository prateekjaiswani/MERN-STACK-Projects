public class Notes {
    import java.util.*;

	public static void main(String[] args) {
		
		// Values of a array are index in count array 
		
// 		int a[] = {0, 1, 2, 5, 0, 9, 1, 2, 4, 1, 3, 5, 6, 1, 2, 3, 5, 7, 2, 8};
// 		int n = a.length;
		
// 		0 <= a[i] <= 100
		
// 		int ct[] = new int[11];
		
// 		for(int i = 0; i < n; i++) {
// 		    ct[a[i]]++;
// 		}
		
// 		for(int i = 0; i < 11; i++) {
// 		    if(ct[i] != 0) {
// 		        System.out.println(i + " " + ct[i]);
// 		    } 
// 		}

        // for(int i = 0; i < n; i++) {
        //     System.out.println(a[i] + " " + ct[a[i]]);
        // }
        
        // Strings 
        
        // Primitive Data Type - Inbuilt data types - int, float, double, boolean, char 
        // Derived Data Type - Dervied from primitive data type - String - char 
        
        Scanner sc = new Scanner(System.in);
        
        // String s = sc.nextLine();
        
        // System.out.println(s);
        
        // String functions 
        // length(), charAt(), indexOf(), equals(), equalsIgnoreCase(), replace()
        
        // int n = s.length(); // O(1)
        
        // System.out.println(n);
        
        // for(int i = 0; i < n; i++) {
        //     System.out.println(s.charAt(i)); // O(1)
        // }
        
        // Please Note: 
        // 1. String constant pool will not have duplicate strings. It checks if string is present before creating one.
        // 2. == always compares address of string irrespective of how they are created 
        // 3. String is immutable. Cannot change size or char at any index 
        
        // 1. The strings are created in string constant pool
        // 2. They both point to same memory address 
        // String s = "hello";
        // String s2 = "hello";
        
        // System.out.println(s);
        // System.out.println(s2);
        
        // 1. The strings are created in heap 
        // 2. They both point to different memory address 
        // String s = new String("hello");
        // String s2 = new String("hello");
        
        // System.out.println(s);
        // System.out.println(s2);
        
        // if(s == s2) { // This is comparing address
        //     System.out.println("Equal");
        // }
        // else {
        //     System.out.println("Not equal");
        // }
        
        // if(s.equals(s2)) { // This is comparing values present in string 
        //     System.out.println("Equal");
        // }
        // else {
        //     System.out.println("Not equal");
        // }
        
        // String concatenation
        
        // String s = "hello";
        // String s2 = "world";
        
        // String s3 = s + s2;
        
        // System.out.println(s3);
        
        // Find the index of given charcter in string 
        // Count the frequency of a given character in string 
        // Find the first and last occurence of a char in string 
        // Count frequency of every character in String (char -> int Lowest 0 and highest 255)
        
        // Check if two strings are equal without using equals() function
        
        // String s1 = "Hello";
        // String s2 = "hello";
        
        // int n1 = s1.length();
        // int n2 = s2.length();
        
        // if(n1 == n2) {
        //     boolean flag = true;
        //     for(int i = 0; i < n1; i++) {
        //         char c1 = s1.charAt(i);
        //         char c2 = s2.charAt(i);
                
        //         if(c1 != c2) {
        //             flag = false;
        //             break;
        //         }
        //     }
            
        //     if(flag == true) {
        //         System.out.println("Strings are equal");
        //     }
        //     else {
        //         System.out.println("Strings are not equal");
        //     }
        // }
        // else {
        //     System.out.println("Strings are not equal");
        // }
        
        // Check if two strings are equal ingnoring case without using equalsIgnoreCase() function
        
        // char c = 'A'; 
        // c = (char)(c + 32);
        
        // String s1 = "Hello";
        // String s2 = "hello";
        
        // int n1 = s1.length();
        // int n2 = s2.length();
        
        // if(n1 == n2) {
        //     boolean flag = true;
        //     for(int i = 0; i < n1; i++) {
        //         char c1 = s1.charAt(i);
        //         char c2 = s2.charAt(i);
                
        //         if(c1 >= 'A' && c1 <= 'Z') {
        //             c1 = (char)(c1 + 32);
        //         }
                
        //         if(c2 >= 'A' && c2 <= 'Z') {
        //             c2 = (char)(c2 + 32);
        //         }
                
        //         if(c1 != c2) {
        //             flag = false;
        //             break;
        //         }
        //     }
            
        //     if(flag == true) {
        //         System.out.println("Strings are equal");
        //     }
        //     else {
        //         System.out.println("Strings are not equal");
        //     }
        // }
        // else {
        //     System.out.println("Strings are not equal");
        // }
        
        // Anagram - "hello" "elhlo"
        
        // 540 -> 300 Easy 200 Medium 40 Hard
        
        // String s = 'b' + "" + 'a';
        
        // System.out.println(s);
        
        // Substring
        
        // String s = "hello world";
        
        // String sub = "";
        
        // for(int i = 3; i <= 7; i++) {
        //     sub = sub + s.charAt(i);
        // }
        
        // System.out.println(s.substring(1, 5));
        
        // String s = "hello"; // "hillo"
        
        // int n = s.length();
        // int k = 1;
        
        // String sub1 = "", sub2 = "";
        
        // for(int i = 0; i < k; i++) {
        //     sub1 = sub1 + s.charAt(i);
        // }
        
        // for(int i = k+1; i < n; i++) {
        //     sub2 = sub2 + s.charAt(i);
        // }
        
        // s = sub1 + 'i' + sub2;
        
        // System.out.println(s);
        
        // Convert a uppercase string to a lowercase string "HELLO" -> "hello"
        
        // String s = "HELlo";
        
        // System.out.println(s.toUpperCase());
        
        // compareTo() 
	}
}


