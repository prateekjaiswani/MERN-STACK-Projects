import java.io.*;
import java.util.*;
public class KeyPadComb {
    static void printKPC(String ques) {
        //Write your code here
        keypad(0,ques,"");
    }

	static void keypad(int index,String num,String ansSoFar){
     String arr[]={".;","abc","def","ghi","jkl","mno","pqrs","tu","vwx","yz"};
     if(index==num.length()) {
        System.out.println(ansSoFar);
        return;
	 }


		int digit=num.charAt(index)-'0';

		for(int i=0;i<arr[digit].length();i++){
			char d=arr[digit].charAt(i);
			keypad(index+1,num,ansSoFar+d);
		}

     }

    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        String str;
        str = sc.nextLine();
        printKPC(str);
    }

}
