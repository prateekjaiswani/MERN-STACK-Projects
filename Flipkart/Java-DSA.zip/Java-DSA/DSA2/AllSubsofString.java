import java.util.*;
import java.util.Scanner;
public class AllSubsofString {
    static void subsequence(String s,int index,String ansSoFar){
		if(index==s.length()){
			System.out.print(ansSoFar+" ");
			return;
		}

		subsequence(s,index+1,ansSoFar+s.charAt(index));
		subsequence(s,index+1,ansSoFar);
	}
	
    static void printSubsequence(String s) {
        //Write your code here
		subsequence(s,0,"");
		
    }
    public static void main(String args[]) {
        Scanner sc = new Scanner(System.in);
        String s = sc.nextLine();
        printSubsequence(s);
    }

}
