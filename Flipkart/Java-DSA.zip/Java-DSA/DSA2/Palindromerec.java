import java.util.*;
public class Palindromerec {


    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] arr = new int[n];
        for (int i = 0; i < n; i++)
            arr[i] = sc.nextInt();
        sc.close();
       
        System.out.println(isPalindrome(arr, n));
    }

	public static boolean isPalindrome(int[] arr, int n) {
        int res = isPalindromic(arr, 0, n - 1);
        if (res == 1)
            return true;
        return false;
    }

    public static int isPalindromic(int[] arr, int begin, int end) {
     if(begin>=end){
		 return 1;
	 }
	  int ans = isPalindromic(arr,begin+1,end-1);

	if(ans==1 && arr[begin]==arr[end]) return 1;
	else return 0;
			
    }

}
