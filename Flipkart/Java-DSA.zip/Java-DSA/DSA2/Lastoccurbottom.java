import java.util.*;

public class Lastoccurbottom {

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
        int N = s.nextInt();
		int[] A = new int[N];
		for(int i = 0; i < N; i++){
			A[i] = s.nextInt();
		}
		int T = s.nextInt();
		System.out.println(lastIndex(A, T, 0));
	}

	static int lastIndex(int A[],int T,int startIndex)
	{
		//Write your code here
		if(startIndex==A.length) return -1;
		int ans = lastIndex(A,T,startIndex+1);
		if(ans!=-1) return ans;
		if(A[startIndex]==T) return startIndex;
		return ans;
       
	}
}

