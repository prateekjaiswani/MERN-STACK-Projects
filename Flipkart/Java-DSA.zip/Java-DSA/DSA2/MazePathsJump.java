import java.util.*;
public class MazePathsJump {



	public static void printMazePaths(int sr, int sc, int dr, int dc, String psf) {
        //Write your code here
		if(sr==dr && sc==dc) {
			System.out.println(psf);
			return;
		}
		if(sr>dr || sc>dc) {
			
			return;
		}

		for(int jump=1;jump<=dc;jump++){
			printMazePaths(sr,sc+jump,dr,dc,psf+"h" + jump );	
		}
		for(int jump=1;jump<=dr;jump++){
			printMazePaths(sr+jump,sc,dr,dc,psf+"v" + jump );
		}
		for(int jump=1;jump<=Math.min(dc,dr);jump++){
			printMazePaths(sr+jump,sc+jump,dr,dc,psf+"d" + jump);
		}

		
    }
    public static void main(String[] args) throws Exception {
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int n = Integer.parseInt(br.readLine());
        int m = Integer.parseInt(br.readLine());
        printMazePaths(0, 0, n - 1, m - 1, "");
    }

}
