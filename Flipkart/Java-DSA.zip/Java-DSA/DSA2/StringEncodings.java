import java.util.*;
import java.util.Scanner;

public class StringEncodings {
     public static void printEncodings(String str,int index,String anssofar) {
        // Write your code here

		if(index==str.length()) {
			System.out.println(anssofar);
			return;
		}

		    if(str.charAt(index)=='0') return;
	   // 1 digit char;
			char digit=(char)(str.charAt(index)-'0'+96);
			printEncodings(str,index+1,anssofar+digit);
			

	   // 2 digit char;
			if(index==(str.length()-1)) return;
			int d=Integer.parseInt(str.substring(index,index+2));
			if(d<=26){
			char digit2=(char)(d+96);
			printEncodings(str,index+2,anssofar+digit2);
			}
		
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String str = sc.nextLine();
        printEncodings(str,0,"");
    }
}
