import java.util.*;

public class ClimbingStaris {

    public static int ClimbingStairs(int n) {
        // Write your code here
		if(n<=2) return n;

		return ClimbingStairs(n-1)+ClimbingStairs(n-2);

    }

    public static void main(String args[]){

        System.out.print(ClimbingStairs(5));
    }
}
