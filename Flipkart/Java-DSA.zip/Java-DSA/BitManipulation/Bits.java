import java.util.*;

public class Bits{
    public static void main(String args[]) {
        int n = 5;
        int pos = 2;
        int bitMask = 1<<pos;


        // get Bit
        // if((bitMask & n) == 0){
        //     System.out.println("bit was 0");

        // }else {
        //     System.out.println("bit was 1");
        // }


        // set Bit
        // int changebit = 1;
        // int newNumber = 1<<changebit | n ;
        // System.out.println(newNumber);

        //Clear Bit
        // int newNumber = ~(1<<pos) & n;
        // System.out.println(newNumber); 

        //Update Bit
        Scanner sc = new Scanner(System.in);
        int oper = sc.nextInt();
        
        if(oper==1){
            int newNumber = 1<<pos | n ;
            System.out.println(newNumber);
        } else {
            int newNumber = ~(1<<pos) & n;
            System.out.println(newNumber);
        }




    }
}