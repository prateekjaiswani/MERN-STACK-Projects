import java.util.*;

public class Arrays {
    
    public static void main(String args[]) {


        //1D ARRAYS

        // int[] marks = new int[3];
        // int marks[] = new int[3];
        // int marks[] = {1,3,4};

        // int size = sc.nextInt();
        // int marks[] = new int[size]; //automatic initialize all values to 0
        //inputs through for loop

        // marks[0]=32;
        // marks[1]=45;
        // marks[2]=65;
        // System.out.println(marks[0]);
        // System.out.println(marks[1]);
        // System.out.println(marks[2]);

        // for(int i=0;i<3;i++){
        //     System.out.println(marks[i]);
        // }
        

        // 2d ARRAYS

        Scanner sc = new Scanner(System.in);
        int rows = sc.nextInt();
        int cols = sc.nextInt();
        int search = sc.nextInt();

        int[][] arr = new int[rows][cols];


        for(int i=0;i<rows;i++){
            for(int j=0;j<cols;j++){
                arr[i][j] = sc.nextInt();
            }
        }


        // for(int i=0;i<rows;i++){
        //     for(int j=0;j<cols;j++){
        //        System.out.print(arr[i][j] + " ");
        //     }
        //     System.out.println();
        // }

            for(int i=0;i<rows;i++){
                for(int j=0;j<cols;j++){
                   if(arr[i][j]==search){
                    System.out.println("Found at " + i +"," +j);
                   }
                }
               
            }






    }

}
