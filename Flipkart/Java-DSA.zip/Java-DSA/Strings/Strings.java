import java.util.*;

public class Strings {
 public static void main(String args[]) {
    // Scanner sc =new Scanner(System.in);
    // String name = sc.nextLine();
    // System.out.println(name);

    // //concatenation
    // String firstName = "tony";
    // String lastName = "stark";
    // String fullname = firstName + " " + lastName;
    // System.out.println(fullname);

    // //charAt
    // for(int i =0; i<fullname.length();i++){
    //     System.out.println(fullname.charAt(i));
    // }

    // //compare
    // //s1>s2 = +ve value
    // //s1==s2 = 0
    // // s1<s2 = -ve value

    // if(lastName.compareTo(firstName) == 0){
    //     System.out.println("string are equal");
    // }else{
    //     System.out.println("Nope not equal");
    // }

    // if(new String("toNY")== new String("toNY")) {
    //     System.out.println("Equal");
    // }else{
    //     System.out.println("Thats why use Compare");
    // }

    // //Sub String

    // String sentence = "Hello I am Pj ";
    // String name = sentence.substring(3, sentence.length()) ;
    // System.out.println(name);

    // StringBuilder

    StringBuilder sb = new StringBuilder("Tony");
    
    sb.setCharAt(0, 'P');
    sb.insert(4,"tail");
    System.out.println(sb);

    sb.append("raaaaam");
    System.out.println(sb);

    //reverse the string
    
    // for(int i = sb.length()-1;i>=0;i--){
    //     System.out.print(sb.charAt(i));
    // }

    for (int i=0;i<sb.length()/2;i++){
        int front = i;
        int back = sb.length()-1-i;

        char frontChar = sb.charAt(front);
        char backChar = sb.charAt(back);

        sb.setCharAt(front, backChar);
        sb.setCharAt(back, frontChar);
    }

    System.out.println(sb);




 }   
}
