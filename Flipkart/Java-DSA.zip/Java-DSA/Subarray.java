import java.util.*;

/// findgeometrictriplet
///// can be done with gcd;

public class Subarray {

    public static boolean prime(int n){
        for(int i=2;i<=Math.sqrt(n);i++){
            if(n%i==0){
                return false;
            }
        }return true;
    }
    public static void findGeometricTriplets(int arr[], int n) {
       int trio[] = new int[3];
        // System.out.print(trio[2]);
        trio[0] = 0;
        trio[1] = 0;
        trio[2] = 0;
        int index = 0;
        int i = 0;
        while (i <= n - 3) {
            // System.out.println("i is"+i);
            int el = arr[i];
            trio[0] = el;
            int j = i + 1;
            while (j<n) {
                if (arr[j] % el == 0) {
                    // System.out.println("j is"+j);
                    int fdiv = arr[j] / el;
                    int fmod = arr[j] % el;
                    trio[1] = arr[j];
                    // System.out.println(fdiv +"and" +fmod);
                    for (int k = j + 1; k < n && trio[2] == 0; k++) {
                        // System.out.println("k is"+k);
                        if (arr[k] / arr[j] == fdiv && arr[k]%arr[j]==fmod ) {
                            trio[2] = arr[k];
                            // System.out.println(" elment entered " + arr[k]);
                        }
                    }
                    if (trio[2] != 0) {
                        index = 0;
                        while (index < 3) {
                            System.out.print(trio[index] + " ");
                            index++;
                        }
                        System.out.println();
                        trio[1] = 0;
                        trio[2] = 0;
                    } else {
                        trio[1] = 0;
                        trio[2] = 0;
                    }
					j++;
                }else{
                    int fdiv = arr[j] ;
                    int fmod = el;
                    while(!prime(fdiv) && !prime(fmod)){
                        fdiv=fdiv/2;
                        fmod=fmod/2;
                    }
                    trio[1] = arr[j];
                    System.out.println(fdiv +"and" +fmod);
                    for (int k = j + 1; k < n && trio[2] == 0; k++) {
                        // System.out.println("k is"+k);
                        if (arr[k] / arr[j] == fdiv && arr[k]%arr[j]==fmod ) {
                            trio[2] = arr[k];
                            // System.out.println(" elment entered " + arr[k]);
                        }
                    }
                    if (trio[2] != 0) {
                        index = 0;
                        while (index < 3) {
                            System.out.print(trio[index] + " ");
                            index++;
                        }
                        System.out.println();
                        trio[1] = 0;
                        trio[2] = 0;
                    } else {
                        trio[1] = 0;
                        trio[2] = 0;
                    }
					j++;

                }
            }
            i++;
        }
    }

    public static void main(String[] args) throws Exception {
        Scanner sc = new Scanner(System.in);
        int N = sc.nextInt();
        int arr[] = new int[N];
        for (int i = 0; i < N; i++) {
            arr[i] = sc.nextInt();
        }
        findGeometricTriplets(arr, N);
        sc.close();
    }
}