import java.util.*;

public class Main {
    public static void main(String[] args) {
        //###output
        // System.out.print("This is Output\n");

        //###variables
        // String name = "Tony Stark";
        // int age = 48;
        // double price = 20000;

        // System.out.print(name + age + price);

        //###input 

        // Scanner sc = new Scanner(System.in);
        // String in = sc.next();
        // System.out.println(in); 
        // sc.close();

        //###conditionals


        //#ifelse

        // Scanner sc =new Scanner(System.in);
        // int age = sc.nextInt();
        // if(age>18){
        //     System.out.println("Adut");
        // } else {
        //     System.out.println("nope");
        // }

        //#Switch

        // Scanner sc =new Scanner(System.in);
        // int Hi = sc.nextInt();
        // switch(Hi) {
        //     case 1: 
        //     System.out.println("Hello");
        //     break;
        //     case 2:
        //     System.out.println("Namastey");
        //     break;
        //     case 3:
        //     System.out.print("bonjour");
        //     break;
        //     default:
        //     System.out.println("Nothing");

        // }

        //###LOOPS

        //for
            // for(int a=0;a<10;a++){
            //     System.out.println(a);
            // }

        //while
        
        // int i = 0;
        // while(i<10){
        //     System.out.println(i);
        //     i++;
            
        // }

        //do while
        //     int a = 1;
        // do {
        //     System.out.println(a);
        //     a++;
        // }while(a<=10);

    }
}