import java.util.ArrayList;


public class Recursion3 {

    // Print all possible Sequences of String

    public static void PrintPermutations(String str, String Permutation) {
        if(str.length()==0){
            System.out.println(Permutation);
            return;
        }

        for(int i=0;i<str.length();i++){
            char currentChar =str.charAt(i);

            String newString = str.substring(0, i)+str.substring(i+1);
            PrintPermutations(newString, Permutation+currentChar);

        }
    }

    // Count All Paths in a Maze 

    public static int CountPaths(int i, int j, int n,int m) {

        if(i==n || j==m){
            return 0;
        }

        if(i==n-1 && j == m-1) {
            return 1;
        }

        //move Down
        int downPaths = CountPaths(i+1, j, n, m);

        //move right
        int righPaths = CountPaths(i, j+1, n, m);

        return downPaths + righPaths;
    }

    // Place 1*m tiles on n*m floor

    public static int PlaceTiles(int n, int m) {

        if(n==m){
            return 2;
        }
        if(n<m){
            return 1;
        }

        
        int vertPlacements = PlaceTiles(n-m, m);
        int horizPlacements= PlaceTiles(n-1, m);

        return vertPlacements + horizPlacements;
    }

    // Single or pair in  a party

    public static int callGuest(int n) {
        if( n<=1 ){
            return 1;
        }


        //single
        int ways1 = callGuest(n-1);

        //pair
        int ways2 = (n-1)*callGuest(n-2);

        return ways1 + ways2;
    }

    // All subset of n natural numbers
    // TC=>O(2^n)

    public static void printSubset(ArrayList<Integer> subset) {
        for(int i=0;i<subset.size();i++){
            System.out.print(subset.get(i)+" ");
        }
        System.out.println();
    }

    public static void findSubsets(int n, ArrayList<Integer> subset) {

        if(n==0){
            printSubset(subset);
            return;
        }

        // to be added
        subset.add(n);
        findSubsets(n-1, subset);

        //not to be
        subset.remove(subset.size()-1);
        findSubsets(n-1, subset);


    }

    public static void main(String args[]) {

        // Print all possible Sequences of string
        String str="abc";
        PrintPermutations(str, "");

        //Count All PAths of a Maze
       // System.out.println(CountPaths(0, 0, 3, 3)); 

       //Place 1*m tile in n*m floor
       // System.out.println(PlaceTiles(4, 2));

       // Call guests as single or mingle ways
    //    System.out.println(callGuest(4));

    //All subsets of n natural number
    // int n =3;
    // ArrayList<Integer> subset = new ArrayList<>();

    // findSubsets(3, subset );
        
    }
}
