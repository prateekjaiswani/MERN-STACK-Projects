public class Recursion {

    //Print Numbers 5 to 1
    public static void PrintNum(int n) {
        if(n==0) return;
        
        System.out.println(n);
        PrintNum(n-1);
    }
    
    //Print sum of n 
    
    public static void PrintSum(int n,int i, int sum) {
        if(i==n){
            sum+=i;
            System.out.println(sum);
            return;
        }
        sum+=i;
        PrintSum(n, i+1, sum);
        //    System.out.println(i); // this prints values on returning
    }
    
    // Print Factoria of N
    
    public static int PrintFactorial(int n) {
        if(n==1 || n==0){
            return 1;
        }
        
        int fact_nm1=PrintFactorial(n-1);
        int fact_n = n*fact_nm1;
        return fact_n;
        // based on back coming values
    }

    // Print Fibonacci sequence
    
    public static void PrintFibonacci(int a, int b, int n) {
        if(n==0) return;

        int c = a + b;
        System.out.println(c);
        PrintFibonacci(b, c, n-1);
    }
    
    //Calculate Power
    
    public static int PrintPower(int x, int n) {
        if(n==0) return 1;
        if(x==0) return 0;
    
        int xPownm1 = PrintPower(x, n-1);
        int xPown = x * xPownm1;
        return xPown;

    }
    //Calculate Power with Logn stack  //// doubt not cleared
    
    public static int PrintPowerLogn(int x, int n) {
        if(n==0) return 1;
        // if(n==1) return x;
        if(x==0) return 0;
    
        if(n%2==0) {
            return PrintPowerLogn(x, n/2) * PrintPowerLogn(x, n/2);
        }else {
            return PrintPowerLogn(x, n/2) * PrintPowerLogn(x, n/2) * x;
            
        }

    }
    


    public static void main(String args[]) {
        
        // PrintNum( 5);
        // PrintSum(5,1,0);
    //    System.out.println(PrintFactorial(5));

        // fibonacci

        // int a = 0;
        // int b= 1;
        // System.out.println(a);
        // System.out.println(b);
        // int n = 7;
        // PrintFibonacci(a, b, n-2);

        //Calculate Power

        int x = 2, n =5 ;

        // System.out.println(PrintPower(x,n));

        // Calculate power with Logn stack

        System.out.println(PrintPowerLogn(x, n));      




    }
}