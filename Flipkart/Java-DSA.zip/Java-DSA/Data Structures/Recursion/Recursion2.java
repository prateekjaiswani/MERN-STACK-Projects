import java.util.HashSet;

public class Recursion2 {

    // TOWER OF HANOI 
    // TC=> O(2^n-1) ~ O(2^n)
    public static void towerOfHanoi(int n, String src, String help, String dest) {
        if(n==1) {
            System.out.println("Transfer of " + n + " from " + src + " to " + dest);
            return; 
        }


        towerOfHanoi(n-1, src, dest, help);
        System.out.println("Transfer of " + n + " from " + src + " to " + dest );
        towerOfHanoi(n-1, help, src, dest);

    }

    //  reverse the string

    public static void ReverseString(String str, int idx ) {
        if(idx==0){
            System.out.println(str.charAt(idx));
            return;
        }
        System.out.println(str.charAt(idx));
        ReverseString(str, idx-1);
    }

    // First and Last occurance of element 
    public static int first = -1;
    public static int last = -1;

    public static void findOccurance(String str, int idx, char element) {
        if(idx==str.length()){
            System.out.println(first);
            System.out.println(last);
            return;
        }

        char currentChar= str.charAt(idx);
        if(currentChar==element){
            if(first==-1) {
                first=idx;
            }else {
                last=idx;
            }
        }

        findOccurance(str, idx+1,element);
    }

    //check array is sorted or not (strictly increasing)

    public static boolean SortOrNot(int arr[],int idx) {
        if(idx == arr.length-1) return true;

        if(arr[idx]>=arr[idx+1]){
            return false;
        }

        return SortOrNot(arr, idx+1);
    }

    // Move all x to last

    public static void moveAllX(String str, int idx, int count, String newString) {

        if(idx == str.length()){
            for(int i = 0; i<=count;i++){
                newString+='x';
            }
            System.out.println(newString);
            return;
        }


        char currentChar = str.charAt(idx);
        if(currentChar=='x'){
            count++;
            moveAllX(str, idx+1, count, newString);
        }else{
            newString+=currentChar;
            moveAllX(str, idx+1, count, newString);
         }
    }

    // Remove Duplicate Strings

    public static boolean[] map = new boolean[26];

    public static void RemoveDuplicates(String str, int idx, String newString) {
        if(idx==str.length()){
            System.out.println(newString);
            return ;
        }

        char currentChar = str.charAt(idx);
        if(map[currentChar-'a']==true){
            RemoveDuplicates(str, idx+1, newString);
        }else{
            newString+=currentChar;
            RemoveDuplicates(str, idx+1, newString);
        }
    }

    // All Subsequences of String 
    //TC => O(2^n)

    public static void Subsequences(String str,int idx, String newString) {
        if(idx == str.length()){
            System.out.println(newString);
            return ;
        }
        char currentChar =str.charAt(idx);

        //to be
        Subsequences(str, idx+1, newString+currentChar);
        
        
        // not to be
        Subsequences(str, idx+1, newString);

    }
    
    // All Unique Subsequences of a String
    
    public static void UniqueSubsequences(String str,int idx, String newString, HashSet<String> set) {
        if(idx == str.length()){
            if(set.contains(newString)) {
                return ;
            }else {    
                System.out.println(newString);
                set.add(newString);
                return;
            }
        }

        char currentChar =str.charAt(idx);

        //to be
        UniqueSubsequences(str, idx+1, newString+currentChar, set);
        
        
        // not to be
        UniqueSubsequences(str, idx+1, newString, set);

    }

    // Print Keypad Combinations
    // TC=> O(4^n)
    // max 4 char options and n sze user String

    public static String[] Keypad = {".","abc","def","ghi","jkl","mno","pqrs","tu","vwx","yz"};

    public static void KeypadCombo(String str, int idx, String combination) {
        if(idx==str.length()){
            System.out.println(combination);
            return ;
        }

        char currentChar = str.charAt(idx);
        String mapping = Keypad[currentChar-'0'];

        for(int i=0;i<mapping.length();i++){
            KeypadCombo(str, idx+1, combination+mapping.charAt(i));
        }

    }

    public static void main(String args[]) {


        //TOWER OF HANOI 
        // int n =3 ;
        // towerOfHanoi(n, "S", "H", "D");

        //Reverse a String
        // String str= "bcdesf";
        // ReverseString(str, str.length()-1 );

        // Find Occurance of element first and last 
        // findOccurance("abcdea", 0 ,'a');

        //Sort Or Not 
        // int arr[]={4,3,6,2,8};
        // System.out.println(SortOrNot(arr, 0));

        // Move all x to last of String
        //   moveAllX("axbxxxcxxd", 0,0,"");

        //Remove Duplicates
        // RemoveDuplicates("axxbbmmsassrekss", 0, null);

        //All Subsequences of String
        // String str="abc";
        // Subsequences(str, 0, "");

        // All Unique Subsequence of String 
        //Hashset
        // String str = "aaa";
        // HashSet<String> set = new HashSet<>();
        // UniqueSubsequences(str, 0, "", set);

        // Keypad Combinations 
        String str ="23";
        KeypadCombo(str, 0, "");
        

    }
}
