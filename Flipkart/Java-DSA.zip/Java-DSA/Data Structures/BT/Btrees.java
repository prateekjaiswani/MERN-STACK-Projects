package BT;

import java.util.LinkedList;
import java.util.Queue;

public class Btrees {

    static class Node {
        int data;
        Node left;
        Node right;

        Node(int data){
            this.data = data;
            this.left = null;
            this.right = null;
        }
    }

    // simple tree
    static class BinaryTree{
        static int idx = -1;
        public static Node BuildTree(int nodes[]) {
            idx++;
            if(nodes[idx]==-1){
                return null;
            }

            Node newNode = new Node(nodes[idx]);
            newNode.left = BuildTree(nodes);
            newNode.right = BuildTree(nodes);

            return newNode;
            
        }
    }

    //tree traversal pre order
    public static void preorder(Node root){
        if(root==null){
            return;
        }
        System.out.println(root.data);
        preorder(root.left);
        preorder(root.right);
    }
    
    
    // in order Traversal 
    
    public static void inorder(Node root){
        if(root==null){
            return;
        }

        inorder(root.left);
        System.out.print(root.data + " ");
        inorder(root.right);
    }
    
    // post order Traversal 
    
    public static void postorder(Node root){
        if(root==null){
            return;
        }

        inorder(root.left);
        inorder(root.right);
        System.out.print(root.data + " ");
    }

    //Level Order Traversal

    public static void levelOrder(Node root) {

        if(root == null){
            return;
        }


        Queue<Node> q = new LinkedList<>();
        q.add(root);
        q.add(null);

        while(!q.isEmpty()){
            Node currNode =  q.remove();
            if(currNode == null){
                System.out.println();
                if(q.isEmpty()){
                    break;
                }else{
                    q.add(null);
                }
            } else{
                System.out.print(currNode.data + " ");
                if(currNode.left != null){
                    q.add(currNode.left);
                }
                if(currNode.right != null){
                    q.add(currNode.right);
                }
            }
        }

    }

    // Count number of Nodes -> Left + Right + 1

    public static int countNodes(Node root){

        if(root==null){
            return 0;
        }


        int leftNodes = countNodes(root.left);
        int rightNodes = countNodes(root.right);

        return leftNodes + rightNodes + 1;

    }

    // Sum of Nodes -> lss + rss + root.data

    
    public static int sumofNodes(Node root){

        if(root==null){
            return 0;
        }


        int leftNodes = sumofNodes(root.left);
        int rightNodes = sumofNodes(root.right);

        return leftNodes + rightNodes + root.data;

    }

    // height of tree

    public static int height(Node root){

        if(root==null){
            return 0;
        }

        int leftHeight = height(root.left);
        int rightHeight = height(root.right);

        int myHeight = Math.max(leftHeight, rightHeight) + 1;

        return myHeight;

    }

    // Approach1 Maximum Diameter of Tree  O(n^2)

    public static int Diameter1(Node root){
        if(root == null){
            return 0;
        }


        int diam1 = Diameter1(root.left);
        int diam2 = Diameter1(root.right);

        int diam3 = height(root.left)+height(root.right) + 1;

        return Math.max(diam3,Math.max(diam1, diam2));


    }
    
    // Approach 2 O(N) Linear 
    
    static class TreeInfo {
        int ht;
        int diam;

        TreeInfo(int ht,int diam){
            this.ht = ht;
            this.diam = diam;
        }
    }

    public static TreeInfo Diameter2(Node root){

        if(root == null){
           return new TreeInfo(0, 0);
        }

        TreeInfo left = Diameter2(root.left);
        TreeInfo right = Diameter2(root.right);

        int myHeight = Math.max(left.ht,right.ht) + 1;

        int diam1 = left.diam;
        int diam2 = right.diam;
        int diam3 = left.ht + right.ht + 1 ;

        int myDiam= Math.max(diam3,Math.max(diam1, diam2));

        TreeInfo myInfo = new TreeInfo(myHeight, myDiam);
        return myInfo;
    }

    // Subtree of another Tree 

    // question from competetive 

    // public boolean isIdentical(TreeNode root, TreeNode subRoot){
    //     if(subRoot == null && root == null){
    //         return true;
    //     }
    //     if(subRoot == null || root == null){
    //         return false;
    //     }

    //     if(root.val==subRoot.val){
    //     return isIdentical(root.left, subRoot.left) && isIdentical(root.right, subRoot.right);
    //     }

    //     return false;
    // }

    // public boolean isSubtree(TreeNode root, TreeNode subRoot){
    //     if(subRoot == null){
    //         return true;
    //     }
    //     if(root == null){
    //         return false;
    //     }

    //     if(root.val==subRoot.val){
    //         if(isIdentical(root,subRoot)) {
    //             return true;
    //         }
    //     }

    //    return isSubtree(root.left, subRoot)  || isSubtree(root.right, subRoot);


    // }

    public static void main(String args[]) {
        int nodes[] ={1,2,4,-1,-1,5,-1,-1,3,-1,6,-1,-1};
        BinaryTree tree= new BinaryTree();
        Node root = tree.BuildTree(nodes);
        // System.out.println(root.data);
        // preorder(root);
        // inorder(root);
        // postorder(root);
        // levelOrder(root);
        // System.out.print( countNodes(root));
        // System.out.print( sumofNodes(root));
        // System.out.print( height(root));
        // System.out.print( Diameter1(root));
        // System.out.print( Diameter2(root).diam);
    }
}
