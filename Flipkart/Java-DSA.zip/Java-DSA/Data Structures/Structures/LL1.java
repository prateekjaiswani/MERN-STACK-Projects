

 class LL1 {


    ListNode head;


    class ListNode {
        String data;
        ListNode next;

        ListNode(String data){
            this.data = data;
            this.next = null;
        }
    }

    public void add(String data){
        ListNode newData = new ListNode(data);
        if (head==null) {
            head=newData;
            return;
        }

        ListNode curr = head;
        while(curr.next !=null){
            curr = curr.next;
        }

        curr.next = newData;
    }

    //Remove nth from last

    public ListNode removeNthfromLast(ListNode head,int n){
            if(head==null){
                return null;
            }

            int size = 0;
            ListNode curr = head;
            while(curr != null){
                curr= curr.next;
                size++;
            }
            System.out.println(size);

            if(n==size){
                return head.next;
            }

            int index = size-n;
            //do size-n+1; to find and print the element

            ListNode prev=head;
            int i = 1;
            //running from 1 to 1 less than desired to make it happen
            while(i < index){
                prev=prev.next;
                i++;
            }
            prev.next = prev.next.next;

            return head;


    }



    public static void main(String args[]) {
            LL1 list = new LL1();
            list.add("1");        
            list.add("2");        
            list.add("3");        
            list.add("4");        
            list.add("5");        
                 
            list.removeNthfromLast(list.head, 2);



            

            
    }
}
