public class LL2 {

    ListNode head;


    class ListNode {
        String data;
        ListNode next;

        ListNode(String data){
            this.data = data;
            this.next = null;
        }
    }

    public void add(String data){
        ListNode newData = new ListNode(data);
        if (head==null) {
            head=newData;
            return;
        }

        ListNode curr = head;
        while(curr.next !=null){
            curr = curr.next;
        }

        curr.next = newData;
    }



    //Find middle of Linked List

    public ListNode findMiddle(ListNode head){

        ListNode hare = head;
        ListNode turtle = head;

        while(hare.next !=null && hare.next.next != null){
            hare = hare.next.next;
            turtle = turtle.next;
        }

        return turtle;

        // if(hare.next!=null) return turtle.next;
		// return turtle;

    }

    //reverse Second Half 

    public ListNode reverse(ListNode head){

        ListNode prev = null;
        ListNode curr= head;

        while(curr != null) {
            ListNode next = curr.next;
            curr.next = prev;
            prev = curr;
            curr = next;
        }
        return prev;
    }

    //Check for Plaindrome

    public boolean isPalindrome(ListNode head){

        if(head==null || head.next==null){
            return true;
        }
        ListNode middle = findMiddle(head); // 1st half end
        ListNode SecondHalfStart = reverse(middle.next);

        ListNode FirstHalfHead = head;
        while(SecondHalfStart != null ){
            if(FirstHalfHead.data != SecondHalfStart.data) {
                return false;
            }
            FirstHalfHead = FirstHalfHead.next;
            SecondHalfStart =SecondHalfStart.next;
        }

        return true;

    }

    //3rd problem check the cycle if there or not 

    public boolean hasCycle(ListNode head){
        if(head==null){
            return false;
        }

        ListNode hare = head;
        ListNode turtle = head;

        while (hare.next != null && hare != null) {
            hare = hare.next.next;
            turtle = turtle.next;

            if(hare == turtle){
                return true;
            }
        }

        return false;
    }

    public static void main(String args[]) {
            LL2 list = new LL2();
            list.add("1");        
            list.add("2");        
            list.add("3");        
            list.add("2");        
            list.add("3");        
                 
           System.out.println(list.isPalindrome(list.head)) ;



            

            
    }
}


