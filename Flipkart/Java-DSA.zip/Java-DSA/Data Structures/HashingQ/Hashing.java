package HashingQ;

import java.util.HashMap;
import java.util.HashSet;

public class Hashing {

    // Q1 - Majority Element

    public static void majorityElement(int nums[]){
        HashMap<Integer, Integer> map = new HashMap<>();
        for(int i=0;i<nums.length;i++){
            if(map.containsKey(nums[i])){
                map.put(nums[i], map.get(nums[i])+1);
            }else{
                map.put(nums[i],1);
            }
        }

        int n=nums.length/3;

        for(int key: map.keySet()){
            if(map.get(key)>n){
                System.out.println(key);
            }
        }
    }

    //Q2- Union of Arrays

    public static void union(int arr1[], int arr2[]) {
        HashSet<Integer> set = new HashSet<>();
        for(int i=0;i<arr1.length;i++){
            set.add(arr1[i]);
        }
        for(int i=0;i<arr2.length;i++){
            set.add(arr2[i]);
        }

        System.out.println(set.size() +"   --Size ");
        for(int k: set){
            System.out.println(k);
        }
    }

    //Q3 - Intersection 
    public static int intersection(int arr1[],int arr2[]) {
        HashSet<Integer> set = new HashSet<>();
        int count=0;

        for(int i=0;i<arr1.length;i++){
            set.add(arr1[i]);
        }

        for(int i=0;i<arr2.length;i++){
            if(set.contains(arr2[i])) {
                count++;
                set.remove(arr2[i]);
            }
        }

        return count;
        
    }

    // Q-4 Find Itinerary from Tickets 
    public static void Itinerary(HashMap<String, String> tmap) {
        HashMap<String, String> revMap = new HashMap<>();
        for(String key: tmap.keySet()){
            revMap.put(tmap.get(key), key);
        }

        String start="";

        for(String key: tmap.keySet()){
            if(!revMap.containsKey(key)){
                start = key;
            }
        }
        System.out.print(start+"->");
        while(tmap.containsKey(start)){

          System.out.print(tmap.get(start) +"->");
          start=tmap.get(start);
        }


    }


    //Q-5 Subarray sum = K   Print all ??????? do it yourself
    

    public static void main(String args[]) {
        // Q1 -  Find Majority Element 
        int nums[] = {1,3,2,5,1,3,1,5,1};

        // majorityElement(nums);

        int arr1[] ={1,2,3};
        int arr2[] ={1,4,5};


        //Q-2 Union of 2 sets
        // union(arr1, arr2);


        //Q-3 Intersection of 2 sets
        // System.out.println(intersection(arr1,arr2));

        //Q-4 Find Itinerary from Tickets
        // HashMap<String,String> tmap = new HashMap<>();
        // tmap.put("Chennai","Bengaluru");
        // tmap.put("Mumbai","Delhi");
        // tmap.put("Goa","Chennai");
        // tmap.put("Delhi","Goa");

        // Itinerary(tmap);

        //Q-5 count Subarray sum = K

        int arr[]={10,2,-2,-20,10};
        int k =-10;
        HashMap<Integer, Integer> map = new HashMap<>();

        map.put(0,1);
        int ans =0;
        int sum =0;
        for(int j=0;j<arr.length;j++){
            sum += arr[j];
            
            if(map.containsKey(sum-k)){
                ans+=map.get(sum-k);
            }

            if(map.containsKey(sum)){
                map.put(sum, map.get(sum)+1);
            }else{
                map.put(sum, 1);
            }

        }

        System.out.println(ans);

    }
}
