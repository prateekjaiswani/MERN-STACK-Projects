package Hashing1;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Map;

public class HashMI {

    static class HashMap<K,V> {// generics values and keys

        private class Node{
        K key;
        V value;

        public Node(K key, V value){ 
            this.key = key;
            this.value = value;
        }
    }

    private int n;
    private int N;
    private LinkedList<Node> buckets[];

    @SuppressWarnings("unchecked")
    public HashMap() {
        this.N = 4;
        this.buckets = new LinkedList[4];
        for(int i=0;i<4;i++){
            this.buckets[i]= new LinkedList<>();
        }
    }

    private int hashFunction(K key){ // bi should be 0 to N-1
        int bi = key.hashCode();
        return Math.abs(bi) % N; // remainder
    }

    private int searchInLL(K key, int bi){
        LinkedList<Node> ll = buckets[bi];
        for(int i=0;i<ll.size();i++){
            if(ll.get(i).key == key){
                return i; //di
            }
        }

        return -1;

    }

    @SuppressWarnings("unchecked")
    private void rehash() {
        LinkedList<Node> oldBucket[] = buckets;
        buckets = new LinkedList[N*2];

        for(int i=0;i<buckets.length;i++){
            buckets[i] = new LinkedList<>();
            
        }

        for(int i =0;i<oldBucket.length; i++){
            LinkedList<Node> ll = oldBucket[i];
            for(int j=0;j<ll.size();j++){
                Node node = ll.get(j);
                put(node.key, node.value);
            }
        }
    }

    public void put(K key,V value){
        int bi = hashFunction(key); // to get bucket index
        int di = searchInLL(key, bi); // to search in bi gives data index (>=0  or -1(not exist in linkedlist)  )

        if(di==-1){  // key not exist 
            buckets[bi].add(new Node(key, value));
            n++;
        }else {  // key exist
            Node data = buckets[bi].get(di);
            data.value = value;
        }

        double lambda = (double)n/N;
        if(lambda > 2.0){
            rehash(); //rehashing
        }
    }

    public V get(K key){
        int bi = hashFunction(key); // to get bucket index
        int di = searchInLL(key, bi); // to search in bi gives data index (>=0  or -1(not exist in linkedlist)  )

        if(di==-1){  // key not exist 
            return null;
        }else {  // key exist
            Node data = buckets[bi].get(di);
           return data.value;
        }
    }

    public boolean containsKey(K key){
        int bi = hashFunction(key); // to get bucket index
        int di = searchInLL(key, bi); // to search in bi gives data index (>=0  or -1(not exist in linkedlist)  )

        if(di==-1){  // key not exist 
            return false;
        }else {  // key exist
            return true;
        }
    }

    public V remove(K key){
        int bi = hashFunction(key); // to get bucket index
        int di = searchInLL(key, bi); // to search in bi gives data index (>=0  or -1(not exist in linkedlist)  )

        if(di==-1){  // key not exist 
            return null;
        }else {  // key exist
            Node data = buckets[bi].remove(di);
            n--;
           return data.value;
        }
    }

    public ArrayList<K> keySet() {
        ArrayList<K> keys = new ArrayList<>();
        for(int i=0;i<buckets.length;i++){
            LinkedList<Node> ll = buckets[i];
            for(int j=0;j<ll.size();j++){
                Node node= ll.get(j);
                keys.add(node.key);
            }
        }
        return keys;
    }

    public boolean isEmpty(){
        return n == 0;
    }

}

    public static void main(String args[]) {
        HashMap<String, Integer> map = new HashMap<>();

        map.put("India",130);
        map.put("US",30);
        map.put("China",120);

        // System.out.println(map);
        
        ArrayList<String> keys = map.keySet();
        for(String key: keys){
            System.out.println(key + ":" + map.get(key));
        }
        
        map.remove("India");
        System.out.println(map.get("India"));
        
        // 
        //
        //
        //
        //

    }
}