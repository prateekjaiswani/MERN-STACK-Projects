package Hashing1;

import java.util.Iterator;
import java.util.HashSet;

public class HashS {
    public static void main(String args[]) {
        //    Create 
        HashSet<Integer> set = new HashSet<>();

    //    Add
        set.add(1);
        set.add(2);
        set.add(3);
        set.add(1); // -> will not be stored 
    
    //    Search - contains 
        if(set.contains(1)){
            System.out.print("exists");
        }
        if(!set.contains(6)){
            System.out.println("Nope");
        }
    
    // Delete 
       set.remove(1);
       if(set.contains(1)){
        System.out.println("Deleted 1");
       }
    
    //Size 
    System.out.println(set.size());
    
    // Print all elements 
    System.out.println(set);
    
    //Iterator 
    Iterator It = set.iterator();
    //hasNext() -> true or false  , next() next value
    
    // It-> null-> 1 ->2 ->3
    
    while(It.hasNext()){
        System.out.print(It.next());
    }
    
    }
}
